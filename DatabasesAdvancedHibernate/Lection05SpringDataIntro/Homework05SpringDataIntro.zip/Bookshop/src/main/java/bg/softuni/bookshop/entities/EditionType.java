package bg.softuni.bookshop.entities;

public enum EditionType {
    NORMAL,
    PROMO,
    GOLD
}
