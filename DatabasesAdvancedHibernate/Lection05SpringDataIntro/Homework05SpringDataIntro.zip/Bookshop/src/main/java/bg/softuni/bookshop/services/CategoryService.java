package bg.softuni.bookshop.services;

import java.io.IOException;

public interface CategoryService {
    void seedCategory() throws IOException;
}
