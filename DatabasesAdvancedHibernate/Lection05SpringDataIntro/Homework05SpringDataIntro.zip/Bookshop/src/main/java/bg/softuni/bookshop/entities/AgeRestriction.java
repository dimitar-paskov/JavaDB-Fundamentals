package bg.softuni.bookshop.entities;

public enum AgeRestriction {
    MINOR,
    TEEN,
    ADULT
}
