package softuni.usersystem.services;

import softuni.usersystem.entities.Picture;

public interface PictureService {
    void save(Picture picture);
}
