package softuni.usersystem.services;

import org.springframework.stereotype.Service;
import softuni.usersystem.entities.Album;


public interface AlbumService {
    void save(Album album);
}
